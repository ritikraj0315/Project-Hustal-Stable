<?php
echo password_hash('your password',PASSWORD_BCRYPT)
?>
