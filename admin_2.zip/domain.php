<?php
$title="Cheap Domain Name Powered By Godaddy.com";
$desc="Register Your Own TLD in Cheap Rates With Free SSL and Free WHOIS Protection. Register Now to Grab Your Domain Before Its Too Late";
include "includes/header.php";
?>
<div class="margin" style="margin-right:5%;margin-left:5%;">
<div class="row">
<div class="col-lg-8 col-md-8"><br>
<h2><b>Find your domains in best price available.</b></h2>
<p class="text-muted">
20+ million customers trust us with their domains. They must know something. All prices advertised apply on every domain name, regardless of whether you want to register, transfer or renew your domain. 
Experts are ready, and they love to get your call.
Low prices and a huge selection. Who doesn't love that?
</p>
</div>
<div class="col-lg-4 col-md-4"><br>
<div class="card bg-light">
<div class="card-body">
<h4><b>Find a prefect domain</b></h4>
<small><i class="fa fa-check-circle-o"></i> .com Domain name is available for only $4.29</small><br>
<a href="https://pk.godaddy.com/domains/domain-name-search" class="btn btn-outline-success d-grid">Register Now</a>
</div>
</div><br>
</div>
<h2 class="text-center"><b>Why choose GoDaddy?</b>
</h2>
<h6 class="text-center text-muted">
With 82+ million domains under management, we have more experience than anyone. We'll make sure you find the right domain and that it's got a secure home online.
</h6>
<div class="col-lg-6 col-md-6"><br>
<div class="card">
<div class="card-body text-center">
<i class="fa fa-globe fa-5x"></i>
<h3><b>World's largest registrar</b></h3>
<p class="text-muted">
More people trust us than any other domain provider. Since the right domain name is important, you want to choose the perfect one. Go with the world's largest registrar.
</p>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6"><br>
<div class="card">
<div class="card-body text-center">
<i class="fa fa-search fa-5x"></i>
<h3><b>Economus Selection</b></h3>
<p class="text-muted">
Every time you enter a name in our domain search box, our powerful engine searches the web's enormous pool of names. There's no better place to find the right domain name for your business.
</p>
</div>
</div><br>
</div>
<h2 class="text-center"><b>Domain Price Chart</b></h2>
<h6 class="text-center text-muted">Domain Price Chart for Popular Domain Names
</h6>
<div class="table-responsive">
<table class="table table-hover table-striped">
<tr>
<th>TLD</th>
<th>Price</th>
<th>Transfer</th>
<th>Renew</th>
<th>Action</th>
</tr>
<tr>
<td class="text-success"><i class="fa fa-globe"></i>  .com</td>
<td>$3.99</td>
<td>$17.99</td>
<td>$17.99</td>
<td><a href="https://godaddy.com" class="btn btn-outline-success">Register</a></td>
</tr>
<tr>
<td class="text-success"><i class="fa fa-globe"></i>  .xyz</td>
<td>$0.99</td>
<td>$18.99</td>
<td>$18.99</td>
<td><a href="https://godaddy.com" class="btn btn-outline-success">Register</a></td>
</tr>
<tr>
<td class="text-success"><i class="fa fa-globe"></i>  .org</td>
<td>$17.99</td>
<td>$17.99</td>
<td>$17.99</td>
<td><a href="https://godaddy.com" class="btn btn-outline-success">Register</a></td>
</tr>
<tr>
<td class="text-success"><i class="fa fa-globe"></i>  .net</td>
<td>$13.99</td>
<td>$14.99</td>
<td>$14.99</td>
<td><a href="https://godaddy.com" class="btn btn-outline-success">Register</a></td>
</tr>
<tr>
<td class="text-success"><i class="fa fa-globe"></i>  .life</td>
<td>$40.99</td>
<td>$40.99</td>
<td>$40.99</td>
<td><a href="https://godaddy.com" class="btn btn-outline-success">Register</a></td>
</tr>
<tr>
<td class="text-success"><i class="fa fa-globe"></i>  .co</td>
<td>$21.99</td>
<td>$40.99</td>
<td>$40.99</td>
<td><a href="https://godaddy.com" class="btn btn-outline-success">Register</a></td>
</tr>
</table>
</div>
</div>
</div>
<?php
include "includes/footer.php";
?>