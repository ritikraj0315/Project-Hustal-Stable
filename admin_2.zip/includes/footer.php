<div class="bg-dark" style="padding:20px;">
<h3 class="text-center text-white"><b>Forget the stereotypes of free hosting!</b></h3><br>
<center><a href="clientarea/signup.php" class="btn btn-light text-dark" rel="nofollow">SIGNUP NOW</a></center>
</div>
<!-- Footer -->
<footer class="bg-light">
  <!-- Grid container -->
  <div class="margin" style="margin-left:5%;margin-right:5%;">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
<div class="col-lg-4 col-md-4 col-sm-12"><br>
<img src="template/image/logo.png" style="width:250px;height:auto;"><br>
<p class="text-muted"> <?php echo SITE_NAME?> is an independent free hosting initiative, dedicated to providing reliable free hosting services.</p>
</div>
<div class="col-lg-3 offset-lg-2 col-md-3 offest-md-2 col-sm-12"><br>
<ul class="list-unstyled">
<li><h5><b>Company</b></h5></li>
<li><a href="privacy.php" style="text-decoration:none;" class="text-dark">Privacy Policy</a></li>
<li><a href="contact.php" style="text-decoration:none;" class="text-dark" >Contact us</a></li>
</ul>
</div>
<div class="col-lg-3 col-md-3 col-sm-12"><br>
<ul class="list-unstyled">
<li><h5><b>Partners</b></h5></li>
<li><a href="https://ifastnet.com/portal/aff.php?aff=<?php echo AFF_ID;?>" style="text-decoration:none;" class="text-dark" >iFastNet</a></li>
<li><a href="https://cloudflare.com" style="text-decoration:none;" class="text-dark" >Cloudflare</a></li>
</ul><br>
</div>
</div>
</div>
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    &copy 2021 Copyright <?php echo SITE_NAME?>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
